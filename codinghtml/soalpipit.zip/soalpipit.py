damage = int(input("Masukan damage: "))
darah_boss = 900
basic_attack = 0
heavy_attack = 0
temp_heavy = 0
skip = 0
turn = 1

while(darah_boss > 0):
    if(turn%4 == 0):
        heavy_attack += 1
        temp_heavy += 1        
    else:
        if(temp_heavy == 0):
            basic_attack += 1
            darah_boss -= damage
        elif(temp_heavy %2 != 0):
            basic_attack += 1
            darah_boss -= damage
        if(temp_heavy%2 == 0):
            if(temp_heavy == 0):
                pass
            else:
                skip += 1
                darah_boss -= damage
                temp_heavy = 0
    if(darah_boss<=0):
        break
    else:
        turn += 1

print(f"""
      Jumlah Putaran                : {turn}
      Jumlah Basik Attack           : {basic_attack}
      Jumlah Heavy Attack           : {heavy_attack}
      Jumlah Tidak Melakukan Aksi   : {skip}
      """)