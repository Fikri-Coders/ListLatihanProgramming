uang = int(input("Berapa Uang Di Dompet: "))
level = [7,10,12]
berapamain = len(level)
easy = 0
normal = 0
hard = 0
extreme = 0
master = 0
tiket = 0
index = 0

while(True):
    if(uang < 12000):
        break
    if(index < berapamain):
        if(level[index] >= 1 and level[index] <= 4):
            easy += 1
            tiket += 3
        elif(level[index]>=5 and level[index]<= 7):
            normal += 1
            tiket += 5
        elif(level[index]>=8 and level[index]<=9):
            hard += 1
            tiket += 8
        elif(level[index]>=10 and level[index]<=11):
            extreme += 1
            tiket += 15
        elif(level[index]>=12):
            master += 1
            tiket += 20
    else:
        break
    uang -= 12000
    index +=1
    
print(f"""
      Uang Tersisa      :{uang}
      Jumlah Bermain    :{index}
      Easy              :{easy}
      Normal            :{normal}
      Hard              :{hard}
      Extreme           :{extreme}
      Master            :{master}
      Total Tiket       :{tiket}
      """)